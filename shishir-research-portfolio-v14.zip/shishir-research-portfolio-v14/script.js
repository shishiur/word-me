const nav = document.getElementById('siteNav');
const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');
const navAnchors = [...document.querySelectorAll('.nav-links a')];
const sections = [...document.querySelectorAll('main section[id]')];
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

document.getElementById('year').textContent = new Date().getFullYear();

function setNavState(){
  nav.classList.toggle('scrolled', window.scrollY > 18);
  let current = sections[0]?.id || 'home';
  for (const section of sections){
    if (window.scrollY >= section.offsetTop - 150) current = section.id;
  }
  navAnchors.forEach(link => link.classList.toggle('active', link.getAttribute('href') === `#${current}`));
}
setNavState();
window.addEventListener('scroll', setNavState, {passive:true});

navToggle.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(open));
  navToggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
});
navAnchors.forEach(link => link.addEventListener('click', () => {
  navLinks.classList.remove('open');
  navToggle.setAttribute('aria-expanded','false');
  navToggle.setAttribute('aria-label','Open menu');
}));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && navLinks.classList.contains('open')){
    navLinks.classList.remove('open');
    navToggle.setAttribute('aria-expanded','false');
    navToggle.focus();
  }
});

for (const button of document.querySelectorAll('.journey-toggle')){
  button.addEventListener('click', () => {
    const id = button.getAttribute('aria-controls');
    const detail = document.getElementById(id);
    const open = button.getAttribute('aria-expanded') === 'true';
    button.setAttribute('aria-expanded', String(!open));
    button.textContent = open ? 'Read the connection' : 'Close details';
    detail.hidden = open;
  });
}

const track = document.getElementById('journeyTrack');
const fill = document.getElementById('journeyFill');
let ticking = false;
function updateJourneyRail(){
  if (!track || !fill) return;
  const rect = track.getBoundingClientRect();
  const viewport = window.innerHeight;
  const start = viewport * .65;
  const end = viewport * .28;
  const travelled = start - rect.top;
  const usable = Math.max(1, rect.height - (start - end));
  const progress = Math.max(0, Math.min(1, travelled / usable));
  fill.style.height = `${progress * 100}%`;
  ticking = false;
}
window.addEventListener('scroll', () => {
  if (!ticking){
    requestAnimationFrame(updateJourneyRail);
    ticking = true;
  }
}, {passive:true});
window.addEventListener('resize', updateJourneyRail);
updateJourneyRail();

const progress = document.getElementById('thesisProgress');
if (progress){
  if (reduceMotion){
    progress.style.width = '90%';
  } else {
    const observer = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)){
        progress.style.width = '90%';
        observer.disconnect();
      }
    }, {threshold:.35});
    observer.observe(progress);
  }
}
