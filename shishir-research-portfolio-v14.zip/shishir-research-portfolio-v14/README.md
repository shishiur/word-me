# Md Shishir Bhuyian Research Portfolio V14

This is the deployable GitHub Pages build.

## Files
- `index.html` main portfolio
- `styles.css` single style system
- `script.js` navigation, research journey disclosure, gliding journey rail and thesis progress
- `academic-cv.html` academic CV
- `assets/` portrait and published research figures

## Design direction
V14 removes generic scientific illustrations, reduces card usage, restores a visible Academic CV and academic background, simplifies the methods section, turns publications into a compact scholarly list, and keeps the research journey as the main interactive storytelling element.
