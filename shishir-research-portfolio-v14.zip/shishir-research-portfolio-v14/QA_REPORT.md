# V14 QA Report

## What was checked

### Pass 1: HTML and link integrity
- No duplicate IDs.
- No broken local anchors.
- No missing local image or CV references.
- All 8 research journey disclosure buttons point to valid detail regions.
- One portrait instance only.
- One credibility metrics block only.
- Academic CV is visible from Hero, About and Contact.

### Pass 2: CSS architecture
- One token system.
- Three responsive breakpoints only: 1024px, 760px and 480px.
- Zero `!important` declarations.
- Zero legacy purple references.
- CSS parses without syntax errors.
- No old V4/V5/V6/V12 override layers.

### Pass 3: density and repetition
- Total visible-source copy reduced to about 1,664 words from the much denser V13 structure.
- Approximate default-visible copy is about 1,403 words because the journey details are collapsed by default.
- Research Journey default-visible copy is about 337 words; deeper context remains available on demand.
- Selected Research reduced to 3 feature cases.
- Publications remain complete at 6 records but are now a compact list rather than a second card gallery.
- Methods reduced to 4 primary groups plus one short computational line.

### Pass 4: punctuation and writing texture
- No em dash in visible portfolio copy.
- No en dash in visible portfolio copy.
- No decorative arrow characters in visible portfolio copy.
- No middle-dot separators in visible portfolio copy.
- Formal scientific hyphenation is retained where it is part of accurate terminology, including `ESBL-Producing` in the thesis title.

### Pass 5: contrast sampling
Against the main background `#071116`:
- Primary text `#f4f7f6`: 17.7:1
- Secondary text `#b6c4c5`: 10.62:1
- Muted text `#819497`: 6.01:1
- Primary teal `#3dc9be`: 9.35:1
- Soft teal `#91e2dc`: 12.82:1
- Warm status accent `#e0b878`: 10.26:1

All sampled values exceed WCAG AA text contrast requirements.

### Pass 6: JavaScript source validation
- `script.js` passes Node syntax validation.
- Menu state, Escape close behavior, journey disclosure, scroll-linked journey rail and thesis progress are implemented with small vanilla JavaScript only.
- `prefers-reduced-motion` is respected by the CSS and thesis progress logic.

## Browser automation note
The available Chromium runtime in this environment is administrator-configured to block `file:`, `data:` and localhost navigation. Because of that restriction, I did not claim a successful automated live-browser regression pass. The source, DOM relationships, CSS, assets, responsive rules, links and JavaScript syntax were checked independently instead.
